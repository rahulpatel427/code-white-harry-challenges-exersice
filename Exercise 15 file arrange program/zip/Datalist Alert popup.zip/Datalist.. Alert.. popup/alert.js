/**
 * 
 */
function successAlert(message) {
	setAlert("Success", message, "alert-success", "bi-check-circle");
}
function failureAlert(message) {
	setAlert("Failure", message, "alert-danger", "bi-x-circle");
}
function dangerAlert(message) {
	setAlert("Danger", message, "alert-warning", "bi-exclamation-triangle");
}
function warningAlert(message) {
	setAlert("Warning", message, "alert-warning", "bi-question-circle");
}
function setAlert(title, message, alertType, alertIcon) {
	const alertHTML = `
    <div class="msg_alert d-flex justify-content-center row col-12">
      <div class="col-lg-6">
        <div class="alert ${alertType} alert-dismissible" role="alert" style="display:none;">
          <i class="bi ${alertIcon} me-1"></i><strong>${title}!</strong> ${message}
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      </div>
    </div>
  `;
	$(".msg_alert").remove();
	$("body").prepend(alertHTML);
	//$(".alert").slideDown();
	$(".alert").fadeIn();
	//$(".alert").show();
	//$(".alert").slideToggle();
	//$(".alert").fadeToggle();

	setTimeout(function() {
		$(".alert").fadeOut();
		$(".msg_alert").remove();

	}, 3000); // Fade out after 3 seconds (3000 milliseconds)
}

function loadAlert(title,msg) {	
	if (msg=="Yes") {
	successAlert(`${title} added Successfully.`);
	}
	else if (msg=="No") {
	failureAlert(`${title} Not added Successfully.`);
	}
	else if (msg=="YesUp") {
	successAlert(`${title} Updated Successfully.`);
	}
	else if (msg=="NoUp") {
	failureAlert(`${title} Not Updated Successfully.`);	
	}
	else if (msg=="YesDel") {
	successAlert(`${title} Deleted Successfully.`);
	}
	else if (msg=="NoDel") {
	failureAlert(`${title} Not Deleted Successfully.`);
	}
	else if (msg=="YesLogin") {
	successAlert(`Login Successfully.`);
	}
}
